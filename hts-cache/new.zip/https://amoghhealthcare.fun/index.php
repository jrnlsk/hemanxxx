<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    
    
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-9FLE79F1RG"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-9FLE79F1RG');
</script>
    <meta charset="utf-8" />
    <title>Among Herb  | Penis Enlargment Pills</title>
    <link rel="icon" href="images/favicon.html" type="image/x-icon">
    <meta name="viewport" content="width=device-width, intial-scale=1">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    
    <script src="../www.google.com/recaptcha/api.js" async defer></script>
   
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="assets/css/icomoon.css" type="text/css" />
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <div class="wrapper">
        <div class="call-order-button">
            <ul>
                <li><a href="tel:+91-9906881209"><img src="assets/images/call-now-button.png"></a></li>
                <li><a href="#enquiry-form"><img src="assets/images/order-now-button.png"></a></li>
            </ul>
        </div>
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-12">
                        <div class="logo">
                            <a href="index.php">
                          <!--    <img src="assets/images/logo.png"></a> -->
                        </div>
                        <div class="contact"><a href="tel:+91-9906881209" class="call-now-button zoomable"><span class="icon"><img src="assets/images/call-now(1).png" /></span>Call Now <br />+91-9906881209</a></div>
                    </div>
                    <div class="col-md-4 hidden-sm hidden-xs">
                        <ul>
                            <li>
                               <img src="assets/images/brand1.png" />
                            </li>
                            <li>
                               <img src="assets/images/brand2.png" />
                            </li>
                            <li>
                               <img src="assets/images/brand3.png" />
                            </li>
                            <li>
                               <img src="assets/images/brand4.png" />
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <div id="banner" style="background-image: url(assets/images/banner4.jpg)">
            <div class="overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-sm-6 visible-xs">
                            <div class="banner-product">
                                <img src="images/cap.png" style="margin-left: -11px;"/><img src="images/oil.png" style="width: 124px;
  margin-top: -213px;
  margin-left: 103px;" />
                                <div class="off"><img src="assets/images/off.png" /></div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                             <div class="content">
                                 <img src="assets/images/offer.png" />
                                 <h2><span>2562 ₹</span>1499 ₹</h2>
                                 <p>बिस्तर पर दिखाएँ अपना दम</p> 
                                 <a href="tel:+91-9906881209" class="call-now-button zoomable"><span class="icon"><img src="assets/images/call.png" /></span>+91-9906881209</a>
                             </div>
                            

                        </div>
                        <div class="col-lg-6 col-sm-6 hidden-xs">
                          <div class="banner-product">
                                <img src="images/cap.png" style="width: 150px;
    margin-left: -31px;
    margin-top: 8px;" /><img src="images/oil.png" style="width: 124px;
  margin-top: -213px;
  margin-left: 89px;" />
                                <div class="off"><img src="assets/images/off.png" /></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       








  <div id="order-form" style="background-image: url(assets/images/banner3.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">



                    </div>
                    <div class="col-md-6">
                        <h3>उन पुरुषों के लिए जो हॉट सेक्स के शौकीन हैं</h3>
                        <div class="form-wrapper" id="enquiry-form">
                            <h2>ऑफर में शेष समय</h2>
                            <h3 id="timer"></h3>
                            <form role="form" method="post" action="eq.php">
                               
                                <div class="form-group">
                                    <input name="name" type="text" id="txtname" class="form-control" placeholder="आपका नाम" />
                                </div>
                                <div class="form-group">
                                    <input name="mobile" type="text" id="txtphone" class="form-control"  pattern="[1-9]{1}[0-9]{9}"  maxlength="10" tabindex="2" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" required="" placeholder="फोन नंबर" />
                                </div>
                               
                                <div class="form-group">
                                    <input  name="city" type="text" id="txtaddress" class="form-control" placeholder="पता" />
                                </div>
                                 <div class="form-group">
                                  <select   name="packages" class="form-control">
                                     <option value="Standard Package - Rs. 1499/-">Standard Package - Rs. 1499/-</option>
                        
 <option value="King Package - Rs. 2499/-">King Package - Rs. 2499/- (2 Month)</option>
                        
                                  </select>
                                    
                                </div>
                                <!--<div class="form-group">-->
                                <!--   <div class="g-recaptcha" data-sitekey=""></div>-->
                                <!--</div>-->
                                
                                <div class="text-center">
                                    <button type="submit" name="save" class="order-now-button">अभी आर्डर करे</button>
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>




        <div id="feature">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 col-xs-6 ">
                        <div class="item">
                            <img src="assets/images/quick.png" />
                            <p>तुरंत खड़ा करें</p>
                        </div>
                    </div>
                    <div class="col-sm-3 col-xs-6 ">
                        <div class="item">
                            <img src="assets/images/repeat.png" />
                            <p>बिना रुके 3 घंटे तक सेक्स</p>
                        </div>
                    </div>
                    <div class="col-sm-3 col-xs-6 ">
                        <div class="item">
                            <img src="assets/images/drop.png" />
                            <p>जबर्दस्त ओरगाज़्म</p>
                        </div>
                    </div>
                    <div class="col-sm-3 col-xs-6 ">
                        <div class="item">
                            <img src="assets/images/increment.png" />
                            <p>लंबाई और मोटाई में बढ़त</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="good-lover" style="background-image: url(assets/images/good-lover.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-7 col-sm-6">
                        <h2>प्रोडक्ट की गुप्त डिलीवरी

भारत भर में<br>क्या आप बनाना चाहते हैं सबसे अच्छे प्रेमी?</h2>
                    </div>
                    <div class="col-lg-4 col-md-5  col-sm-6">
                        <div >
                            <a href="tel:+91-9906881209" class="call-now-button zoomable"><span class="icon"><img src="assets/images/button-call-us-now.png" /></span> +91 9906881209</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="benifits">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="image">
                            <img src="images/cap.png" style="width: 150px;" />
                        </div>
                        <div class="content">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/tick-icon.png" />
                                    </div>
                                    <div class="text">
                                        <p>1 घंटे तक नॉन-स्टॉप सेक्स</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/tick-icon.png" />
                                    </div>
                                    <div class="text">
                                        <p>एक महीने में लिंग का साइज़ +5 सेमी बढ़ाएँ</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/tick-icon.png" />
                                    </div>
                                    <div class="text">
                                        <p>अपनी कामेच्छा बढ़ाएँ Among Herb-43 से और सेक्स के लिए हमेशा तैयार रहें</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="benifits2">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="image">
                            <img src="assets/images/1.gif" />
                        </div>
                        <div class="content">
                            <p>इस कैप्सूल में मिलाए गए नैचुरल पदार्थ जननांगों में रक्त प्रवाह बढ़ाते हैं जिससे कामेच्छा बहुत बढ़ जाती है।</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="image">
                            <img src="assets/images/2.gif" />
                        </div>
                        <div class="content">
                            <p>कैप्सूल से रक्त प्रवाह बेहतर हो जाता है और लिंग का साइज़ बढ़ जाता है। इससे लिंग शिथिल और खड़ी, दोनों अवस्थाओं में बड़ा हो जाता है। गहराई तक अंदर जाने से आप और आपकी पार्टनर दोनों को सेक्स में ज़्यादा आनंद आता है।</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="image">
                            <img src="assets/images/3.gif" />
                        </div>
                        <div class="content">
                            <p>इस कैप्सूल के सक्रिय अवयव स्तंभन को कई घंटों तक बनाए रखने में मदद करते हैं। ओरगाज़्म के 5 मिनट के भीतर आप दोबारा सेक्स करने को तैयार हो जाएंगे।</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="feature2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="image">
                            <img src="assets/images/girl.png" />
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="content">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/vagina.png" />
                                    </div>
                                    <div class="text">
                                        <p>कठोर भेदन जिससे ज़्यादा आनंद मिलेगा</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/fire.png" />
                                    </div>
                                    <div class="text">
                                        <p>यह आत्मविश्वास कि आपको हमेशा और हर जगह लड़कियाँ पसंद करेंगी</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <img src="assets/images/best-couple.png" />
                                    </div>
                                    <div class="text">
                                        <p>यह समझ कि आप अपनी माशूका की ज़िंदगी के सबसे बेहतरीन प्रेमी हैं</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="late">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                       <h1>देर न करें!</h1>
                        <h3>आप यहीं लटके हुए हैं, और दूसरे मजे ले रहे हैं</h3> 
                        <a href="tel:+91-9906881209" class="zoomable"><h2>Call Now</h2><p>+91-9906881209</p></a>
                    </div>
                </div>
            </div>
        </div>
        <div id="testimonials">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="item">
                            <div class="image" style="background-image: url(assets/images/testimonial1.jpg);"></div>
                            <div class="text">
                                <div class="content">
                                    <h3>बबलु, उम्र 26</h3>
                                    <p>मुझे लगता है कि इस्तेमाल के लिए 15.5 सेमी एक पूरी तरह से सामान्य आकार होता है । बेशक, सेक्स हमेशा तारकीय नहीं था। मेने Among Herb-43 को ऑनलाइन देखा और सोचा, क्यों ना कुछ सेन्टीमीटर्स के एक जोड़े पर जोड़ हो । एक महीने और दैनिक उपयोग के भीतर, मैं लगभग 3 सेमी हो गयी, और मेरा लिंग काफ़ी मोटा और कठिन हो गया।</p>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="image" style="background-image: url(assets/images/testimonial2.jpg);"></div>
                            <div class="text">
                                <div class="content">
                                    <h3> धीरज, उम्र 24</h3>
                                    <p>मेरा लिंग मुश्किल से खड़ा 12 सेमी तक होता है, समय के साथ, मैने सब कुछ करने की कोशिश की - गोलियाँ, पंप, मैं शून्य परिणाम के साथ उस पर मेरे सारे वेतन खर्च किए। नियमित रूप से उपयोग के 2 हफ्तों के बाद, मैंने देखा परिणाम - मेरे लिंग 1.5 सेमी लंबे समय तक बने। अपनी संवेदनशीलता बस अपार मिल गया, और मेरी इरेक्शन ज्यादा मजबूत हो गया हैं!</p>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="image" style="background-image: url(assets/images/testimonial3.jpg);"></div>
                            <div class="text">
                                <div class="content">
                                    <h3> प्रमोद , उम्र 42</h3>
                                    <p>नई माओं के लिए तो इससे बढ़िया चीज कोई और हो ही नहीं सकती! Among Herb-43 उपयोग करने के बाद हर बार बिस्तर में ऐसा एहसास होता है मानो पत्नी के साथ पहली बार सेक्स कर रहा हूँ। बड़ी टाइट फीलिंग आती है!</p>
                                </div>

                            </div>
                        </div>
                        <div class="item">
                            <div class="image" style="background-image: url(assets/images/testimonial4.jpg);"></div>
                            <div class="text">
                                <div class="content">
                                    <h3>जसवीर, उम्र 27</h3>
                                    <p>छोटे लिंग वाले लोगों के लिए ये बढ़िया हल है! मैंने तो ऑपरेशन तक का सोच लिया था और अब इतनी लड़कियाँ मिलती हैं कि क्या बताऊँ! वो सोचती हैं मैं कामदेव हूँ!</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="content">
                            <span>&copy; 2023 Copyright. All rights reserved (Among Herb-43).</span><br>
                            <p>
                                The results may vary depending on your individual features<br>
                                आपके सोर्स डाटा और निजी गुण-धर्मों के आधार पर नतीजे अलग-अलग हो सकते हैं
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </footer>
        <div class="fixed-footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-2 col-sm-3 col-xs-4">
                          <a href="#enquiry-form"> <div class="image"><img src="assets/images/footer-product.png" /></a></div>
                    </div>
                    <div class="col-md-5 col-sm-4 col-xs-8">
                        <a href="tel:+91-9906881209" class="call-now-button"><span class="icon"><img src="assets/images/call.png" /></span>+91-9906881209</a>
                        <a href="#enquiry-form" class="order-now-button visible-xs"><span class="icon"><img src="assets/images/cart.png" /></span>अभी आर्डर करे</a>
                    </div>
                    <div class="col-md-5 col-sm-5 hidden-xs">
                        <a href="#enquiry-form" class="order-now-button"><span class="icon"><img src="assets/images/cart.png" /></span>अभी आर्डर करे</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.1.11.3.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/js/owlcarousel/owl.carousel.css">
    <script src="assets/js/owlcarousel/owl.carousel.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll <= 500) {
                    $(".fixed-footer").removeClass("open");

                } else {
                    $(".fixed-footer").addClass("open");
                }
            });
        });
    </script>
    <script>
        // Set the date we're counting down to
        //var countDownDate = new Date("Aug 25, 2018 10:37:25").getTime();
        //new Date(milliseconds + 4 * 3600 * 1000 /*4 hrs in ms*/)

        var countDownDate = new Date();
        countDownDate.setTime(countDownDate.getTime() + 1.5 * 3600 * 1000);

        // Update the count down every 1 second
        var x = setInterval(function () {

            // Get todays date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("timer").innerHTML = hours + "h:" + minutes + "m:" + seconds + "s ";

            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("timer").innerHTML = "OFFER .EXPIRED";
            }
        }, 1000);



</script>
</body>
<style type="text/css">
  .offer h3 {
    font-size: 48px;
    color: #fff;
    line-height: 70px;
}
#late a p, s {
    font-size: 18px;
}

.pricing .price-block h5 {
    font-size: 50px;
    line-height: 60px;
}
.offer {
    padding: 100px 0;
    position: relative;
    overflow: hidden;
    background: linear-gradient(217deg, #000, rgba(255, 0, 0, 0) 70.71%), linear-gradient(127deg, #000, #0f2240 70.71%), linear-gradient(336deg, #f9b232, #f9b232 70.71%)!important;
}
.price-block {
    margin-bottom: 20px;
}.prod2 {
    width: 26%;
}
.mb-3, .my-3 {
    margin-bottom: 1rem!important;
}
.img-fluid, .img-thumbnail {
    max-width: 100%;
    height: auto;
}
img {
    max-width: 100%;
    height: auto;
}#late a p, s {
    font-size: 18px;
}
s {
    margin-right: 5px;
}
*, :after, :before {
    box-sizing: border-box;
}
user agent stylesheet
s {
    text-decoration: line-through;
}
.pricing .price-block h5 {
    font-size: 50px;
    line-height: 60px;
}
</style>

</html>
